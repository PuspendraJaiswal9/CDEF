import { useState } from "react";

function Login({ onLogin }) {
  const [username, setUsername] = useState(""); 
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    try {
      const response = await fetch("http://localhost:8086/user/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        const data = await response.json();

        if (data.token) {
          localStorage.setItem("token", data.token);
          localStorage.setItem("username", username);
          setMessage("✅ Login successful!");
          if (typeof onLogin === "function") onLogin(username);
        } else {
          setMessage("❌ Login failed: token not received.");
        }
      } else {
        setMessage("❌ Invalid username or password!");
      }
    } catch (error) {
      console.error("Error:", error);
      setMessage("⚠️ Something went wrong!");
    }
  };

  return (
    <div className="form-container" style={{ textAlign: "center", marginTop: "10px" }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        /><br /><br />
        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        /><br /><br />
        <button type="submit">Login</button>
      </form>
      {message && <p style={{ marginTop: "10px" }}>{message}</p>}
    </div>
  );
}

export default Login;
