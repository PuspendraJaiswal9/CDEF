import { useState } from "react";

function Register({ onRegisterSuccess }) {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    try {
      const response = await fetch("http://localhost:8086/user/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, email, password }),
      });

      if (response.ok) {
        const data = await response.json();
        setMessage(`✅ Registered: ${data.username || username}. Please login.`);
        if (typeof onRegisterSuccess === "function") onRegisterSuccess(data);
        setUsername("");
        setEmail("");
        setPassword("");
      } else {
        const text = await response.text();
        setMessage("❌ Registration failed: " + (text || response.status));
      }
    } catch (error) {
      console.error("Error:", error);
      setMessage("⚠️ Something went wrong!");
    }
  };

  return (
    <div className="form-container" style={{ textAlign: "center", marginTop: "10px" }}>
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        /><br /><br />
        <input
          type="email"
          placeholder="Enter Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        /><br /><br />
        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        /><br /><br />
        <button type="submit">Register</button>
      </form>
      {message && <p style={{ marginTop: "10px" }}>{message}</p>}
    </div>
  );
}

export default Register;
