import { useState } from "react";
import "./FareOperation.css";

function FareOperation() {
  const [singleFare, setSingleFare] = useState(null);
  const [message, setMessage] = useState("");
  const [activeForm, setActiveForm] = useState(""); // add, update, get, delete
  const [formData, setFormData] = useState({
    fareId: "",
    workshopId: "",
    price: "",
  });

  const API_URL = "http://localhost:8083/fares";

  const getHeaders = (isJson = true) => {
    const headers = {};
    if (isJson) headers["Content-Type"] = "application/json";
    const token = localStorage.getItem("token");
    if (token) headers["Authorization"] = `Bearer ${token}`;
    return headers;
  };

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async () => {
    setMessage("");
    setSingleFare(null);
    try {
      let res;
      const payload = {
        fareId: Number(formData.fareId),
        workshopId: Number(formData.workshopId),
        price: Number(formData.price),
      };

      switch (activeForm) {
        case "add":
          res = await fetch(API_URL, { method: "POST", headers: getHeaders(true), body: JSON.stringify(payload) });
          if (res.ok) {
            setMessage("✅ Fare added successfully!");
            setFormData({ fareId: "", workshopId: "", price: "" });
          }
          break;

        case "update":
          if (!formData.fareId) { setMessage("⚠️ Enter Fare ID to update"); return; }
          res = await fetch(`${API_URL}/${formData.fareId}`, { method: "PUT", headers: getHeaders(true), body: JSON.stringify(payload) });
          if (res.ok) {
            setMessage("✅ Fare updated successfully!");
            setFormData({ fareId: "", workshopId: "", price: "" });
          }
          break;

        case "get":
          if (!formData.fareId) { setMessage("⚠️ Enter Fare ID to get"); return; }
          res = await fetch(`${API_URL}/${formData.fareId}`, { headers: getHeaders(false) });
          if (res.ok) {
            const data = await res.json();
            setSingleFare(data);
            setMessage("ℹ️ Fare fetched!");
          }
          break;

        case "delete":
          if (!formData.fareId) { setMessage("⚠️ Enter Fare ID to delete"); return; }
          res = await fetch(`${API_URL}/${formData.fareId}`, { method: "DELETE", headers: getHeaders(false) });
          if (res.ok) {
            setMessage(`🗑️ Fare with ID ${formData.fareId} deleted`);
            setFormData({ fareId: "", workshopId: "", price: "" });
          }
          break;

        default:
          break;
      }

      if (res && !res.ok) {
        const text = await res.text();
        setMessage("❌ Error: " + (text || res.status));
      }
    } catch (err) {
      console.error(err);
      setMessage("⚠️ Something went wrong!");
    }
  };

  return (
    <div className="fare-container">
      <h3>Fare Operations</h3>

      <div className="button-group">
        <button onClick={() => { setActiveForm("add"); setMessage(""); setSingleFare(null); }}>Add Fare</button>
        <button onClick={() => { setActiveForm("update"); setMessage(""); setSingleFare(null); }}>Update Fare</button>
        <button onClick={() => { setActiveForm("get"); setMessage(""); setSingleFare(null); }}>Get Fare</button>
        <button onClick={() => { setActiveForm("delete"); setMessage(""); setSingleFare(null); }}>Delete Fare</button>
      </div>

      {activeForm && (
        <div className="fare-form">
          {(activeForm === "add" || activeForm === "update") && (
            <>
              <input type="number" name="fareId" placeholder="Fare ID" value={formData.fareId} onChange={handleChange} />
              <input type="number" name="workshopId" placeholder="Workshop ID" value={formData.workshopId} onChange={handleChange} />
              <input type="number" step="0.01" name="price" placeholder="Price" value={formData.price} onChange={handleChange} />
            </>
          )}
          {(activeForm === "get" || activeForm === "delete") && (
            <input type="number" name="fareId" placeholder="Enter Fare ID" value={formData.fareId} onChange={handleChange} />
          )}
          <button onClick={handleSubmit}>Submit</button>
        </div>
      )}

      {message && <p className="message">{message}</p>}

      {activeForm === "get" && singleFare && (
        <div className="fare-detail">
          <h4>Fare Details</h4>
          <p><strong>Fare ID:</strong> {singleFare.fareId}</p>
          <p><strong>Workshop ID:</strong> {singleFare.workshopId}</p>
          <p><strong>Price:</strong> ₹{singleFare.price}</p>
        </div>
      )}
    </div>
  );
}

export default FareOperation;
