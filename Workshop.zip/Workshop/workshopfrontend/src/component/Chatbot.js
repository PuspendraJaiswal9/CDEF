import { useState } from "react";
import './Chatbot.css';
import chatbotIcon from '../Image/chatbot.png';

function Chatbot() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [isOpen, setIsOpen] = useState(false);

  const API_URL = "http://localhost:8085/chatbot/ask";

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMessage = { sender: "You", text: input };
    setMessages([...messages, userMessage]);
    setInput("");

    try {
      const res = await fetch(`${API_URL}?message=${encodeURIComponent(input)}`);
      if (res.ok) {
        const botReply = await res.text();
        setMessages(prev => [...prev, { sender: "Bot", text: botReply }]);
      } else {
        setMessages(prev => [...prev, { sender: "Bot", text: "⚠️ Error contacting chatbot" }]);
      }
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { sender: "Bot", text: "⚠️ Something went wrong!" }]);
    }
  };

  return (
    <>
      <div className="chatbot-float-icon" onClick={() => setIsOpen(!isOpen)}>
        <img src={chatbotIcon} alt="Chatbot" />
      </div>

      {isOpen && (
        <div className="chatbot-container">
          <div className="chat-header">
            <span>Chatbot</span>
            <button onClick={() => setIsOpen(false)}>×</button>
          </div>
          <div className="chatbox">
            {messages.map((msg, idx) => (
              <div key={idx} className={msg.sender === "You" ? "user-msg" : "bot-msg"}>
                <strong>{msg.sender}: </strong>{msg.text}
              </div>
            ))}
          </div>
          <div className="chat-input">
            <input
              type="text"
              placeholder="Type your message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            />
            <button onClick={sendMessage}>Send</button>
          </div>
        </div>
      )}
    </>
  );
}

export default Chatbot;
