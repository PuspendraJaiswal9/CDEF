import { useState, useEffect } from "react";
import './WorkshopOperation.css';

function WorkshopOperation() {
  const [workshops, setWorkshops] = useState([]);
  const [singleWorkshop, setSingleWorkshop] = useState(null);
  const [formData, setFormData] = useState({
    title: "", description: "", date: "", startTime: "", endTime: "",
    venue: "", capacity: "", availableSeats: "", amount: "", createdBy: ""
  });
  const [activeForm, setActiveForm] = useState(""); 
  const [message, setMessage] = useState("");
  const [idInput, setIdInput] = useState("");

  const API_URL = "http://localhost:8081/api/workshops";

  const getHeaders = (isJson = true) => {
    const headers = {};
    if (isJson) headers["Content-Type"] = "application/json";
    const token = localStorage.getItem("token");
    if (token) headers["Authorization"] = `Bearer ${token}`;
    return headers;
  };

  const fetchWorkshops = async () => {
    try {
      const res = await fetch(API_URL, { headers: getHeaders(false) });
      if (res.ok) {
        const data = await res.json();
        setWorkshops(data);
        setMessage("ℹ️ Fetched all workshops");
      } else setMessage("⚠️ Failed to fetch workshops");
    } catch (err) {
      console.error(err);
      setMessage("⚠️ Error occurred while fetching workshops");
    }
  };

  useEffect(() => { 
    if (activeForm === "all") {
      fetchWorkshops(); 
      setSingleWorkshop(null); // list दिख रही है तो single workshop hide कर दो
    } else {
      setWorkshops([]); // दूसरा form चुनने पर list auto-hide हो जाएगी
    }
  }, [activeForm]);

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async () => {
    setMessage("");
    try {
      let res;
      const payload = {
        title: formData.title, description: formData.description, date: formData.date,
        startTime: formData.startTime, endTime: formData.endTime, venue: formData.venue,
        capacity: Number(formData.capacity), availableSeats: Number(formData.availableSeats),
        amount: Number(formData.amount), createdBy: formData.createdBy
      };

      switch (activeForm) {
        case "add":
          res = await fetch(API_URL, { method: "POST", headers: getHeaders(true), body: JSON.stringify(payload) });
          if (res.ok) { 
            setMessage("✅ Workshop added!"); 
            setFormData({ title:"",description:"",date:"",startTime:"",endTime:"",venue:"",capacity:"",availableSeats:"",amount:"",createdBy:"" }); 
            fetchWorkshops(); 
          }
          break;

        case "update":
          if (!idInput) { setMessage("⚠️ Enter Workshop ID to update"); return; }
          res = await fetch(`${API_URL}/${idInput}`, { method: "PUT", headers: getHeaders(true), body: JSON.stringify(payload) });
          if (res.ok) { setMessage("✅ Workshop updated!"); fetchWorkshops(); }
          break;

        case "get":
          if (!idInput) { setMessage("⚠️ Enter Workshop ID to fetch"); return; }
          res = await fetch(`${API_URL}/${idInput}`, { headers: getHeaders(false) });
          if (res.ok) {
            const data = await res.json();
            setSingleWorkshop(data); // 👉 अब single workshop detail set होगी
            setMessage("ℹ️ Workshop fetched!");
          }
          break;

        case "delete":
          if (!idInput) { setMessage("⚠️ Enter Workshop ID to delete"); return; }
          res = await fetch(`${API_URL}/${idInput}`, { method: "DELETE", headers: getHeaders(false) });
          if (res.ok) { 
            setMessage(`🗑️ Workshop with ID ${idInput} deleted`); 
            setFormData({ title:"",description:"",date:"",startTime:"",endTime:"",venue:"",capacity:"",availableSeats:"",amount:"",createdBy:"" }); 
            fetchWorkshops(); 
          }
          break;

        default: break;
      }

      if (res && !res.ok) {
        const text = await res.text();
        setMessage("❌ Error: " + (text || res.status));
      }
    } catch (err) {
      console.error(err);
      setMessage("⚠️ Something went wrong!");
    }
  };

  return (
    <div className="workshop-container">
      <h2>Workshop Operations</h2>

      <div className="button-group">
        <button onClick={() => setActiveForm("add")}>Add Workshop</button>
        <button onClick={() => setActiveForm("update")}>Update Workshop</button>
        <button onClick={() => setActiveForm("get")}>Get Workshop</button>
        <button onClick={() => setActiveForm("delete")}>Delete Workshop</button>
        <button onClick={() => setActiveForm("all")}>Get All Workshops</button>
      </div>

      {activeForm !== "all" && (
      <div className="workshop-form">
        {(activeForm === "add" || activeForm === "update") && (
          <>
            {activeForm === "update" && <input type="number" placeholder="Workshop ID" value={idInput} onChange={(e)=>setIdInput(e.target.value)} />}
            <input type="text" name="title" placeholder="Title" value={formData.title} onChange={handleChange} />
            <input type="text" name="description" placeholder="Description" value={formData.description} onChange={handleChange} />
            <input type="date" name="date" value={formData.date} onChange={handleChange} />
            <input type="time" name="startTime" value={formData.startTime} onChange={handleChange} />
            <input type="time" name="endTime" value={formData.endTime} onChange={handleChange} />
            <input type="text" name="venue" placeholder="Venue" value={formData.venue} onChange={handleChange} />
            <input type="number" name="capacity" placeholder="Capacity" value={formData.capacity} onChange={handleChange} />
            <input type="number" name="availableSeats" placeholder="Available Seats" value={formData.availableSeats} onChange={handleChange} />
            <input type="number" step="0.01" name="amount" placeholder="Amount" value={formData.amount} onChange={handleChange} />
            <input type="text" name="createdBy" placeholder="Created By" value={formData.createdBy} onChange={handleChange} />
          </>
        )}

        {(activeForm === "get" || activeForm === "delete") && (
          <input type="number" placeholder="Workshop ID" value={idInput} onChange={(e)=>setIdInput(e.target.value)} />
        )}

        <button onClick={handleSubmit}>Submit</button>
      </div>
      )}

      {message && <p className="message">{message}</p>}

      {/* All Workshops */}
      {activeForm === "all" && workshops.length > 0 && (
        <div className="workshop-list">
          <h3>All Workshops</h3>
          <ul>
            {workshops.map(w => (
              <li key={w.workshopId}>
                <strong>{w.title}</strong> | {w.date} | {w.venue} | Seats: {w.availableSeats}/{w.capacity} | ₹{w.amount}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Single Workshop */}
      {activeForm === "get" && singleWorkshop && (
        <div className="workshop-detail">
          <h3>Workshop Details</h3>
          <p><strong>Title:</strong> {singleWorkshop.title}</p>
          <p><strong>Description:</strong> {singleWorkshop.description}</p>
          <p><strong>Date:</strong> {singleWorkshop.date}</p>
          <p><strong>Time:</strong> {singleWorkshop.startTime} - {singleWorkshop.endTime}</p>
          <p><strong>Venue:</strong> {singleWorkshop.venue}</p>
          <p><strong>Seats:</strong> {singleWorkshop.availableSeats}/{singleWorkshop.capacity}</p>
          <p><strong>Amount:</strong> ₹{singleWorkshop.amount}</p>
          <p><strong>Created By:</strong> {singleWorkshop.createdBy}</p>
        </div>
      )}
    </div>
  );
}

export default WorkshopOperation;
