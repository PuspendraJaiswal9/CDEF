import { useState } from "react";
import './BookingOperation.css';
import { loadStripe } from "@stripe/stripe-js";

function BookingOperation() {
  const [bookingDetails, setBookingDetails] = useState(null);
  const [message, setMessage] = useState("");
  const [activeForm, setActiveForm] = useState(""); 
  const [formData, setFormData] = useState({
    name: "",
    workshopId: "",
    numberOfBooking: "",
    bookingId: "",
  });

  const API_URL = "http://localhost:8082/api/bookings";
  const STRIPE_PUBLIC_KEY = "pk_test_51RY008Qp1eyEiksj3NkLSUAMyrHhCjARJvUzUIILUbJrkCW3gzZdOZaHNdU8i3EHjlkjPVAqSYYYqXyHkhLTF10600IVx36azv"; // <-- Tera Stripe public key

  const getHeaders = (isJson = true) => {
    const headers = {};
    if (isJson) headers["Content-Type"] = "application/json";
    const token = localStorage.getItem("token");
    if (token) headers["Authorization"] = `Bearer ${token}`;
    return headers;
  };

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleAddBooking = async () => {
    setMessage("");
    setBookingDetails(null);

    const payload = {
      name: formData.name,
      workshopId: Number(formData.workshopId),
      numberOfBooking: Number(formData.numberOfBooking),
    };

    try {
      const bookingRes = await fetch(API_URL, { method: "POST", headers: getHeaders(true), body: JSON.stringify(payload) });
      if (!bookingRes.ok) {
        const text = await bookingRes.text();
        setMessage(`❌ Error: ${bookingRes.status} - ${text}`);
        return;
      }

      const bookingData = await bookingRes.json();
      setBookingDetails(bookingData);

      if (!bookingData.sessionId) {
        setMessage("⚠️ Payment session not available.");
        return;
      }

      const stripe = await loadStripe(STRIPE_PUBLIC_KEY);
      const { error } = await stripe.redirectToCheckout({ sessionId: bookingData.sessionId });

      if (error) {
        setMessage("⚠️ Stripe error: " + error.message);
      }

    } catch (err) {
      console.error(err);
      setMessage("⚠️ Something went wrong! " + err.message);
    }
  };

  const handleSubmit = async () => {
    switch (activeForm) {
      case "add":
        await handleAddBooking();
        setFormData({ name: "", workshopId: "", numberOfBooking: "", bookingId: "" });
        break;
      case "update":
        if (!formData.bookingId) { setMessage("⚠️ Enter Booking ID"); return; }
        const updateRes = await fetch(`${API_URL}/${formData.bookingId}`, { method: "PUT", headers: getHeaders(true), body: JSON.stringify({
          name: formData.name,
          workshopId: Number(formData.workshopId),
          numberOfBooking: Number(formData.numberOfBooking)
        })});
        if (updateRes.ok) {
          const data = await updateRes.json();
          setBookingDetails(data);
          setMessage("✅ Booking updated successfully!");
        }
        break;
      case "get":
        if (!formData.bookingId) { setMessage("⚠️ Enter Booking ID"); return; }
        const getRes = await fetch(`${API_URL}/${formData.bookingId}`, { headers: getHeaders(false) });
        if (getRes.ok) {
          const data = await getRes.json();
          setBookingDetails(data);
          setMessage("ℹ️ Booking fetched!");
        }
        break;
      case "delete":
        if (!formData.bookingId) { setMessage("⚠️ Enter Booking ID"); return; }
        const delRes = await fetch(`${API_URL}/${formData.bookingId}`, { method: "DELETE", headers: getHeaders(false) });
        if (delRes.ok) {
          setBookingDetails(null);
          setMessage(`🗑️ Booking with ID ${formData.bookingId} deleted`);
        }
        break;
      default:
        return;
    }
  };

  return (
    <div className="booking-container">
      <h3>Booking Operations</h3>

      <div className="button-group">
        <button onClick={() => { setActiveForm("add"); setMessage(""); setBookingDetails(null); }}>Add Booking</button>
        <button onClick={() => { setActiveForm("update"); setMessage(""); setBookingDetails(null); }}>Update Booking</button>
        <button onClick={() => { setActiveForm("get"); setMessage(""); setBookingDetails(null); }}>Get Booking</button>
        <button onClick={() => { setActiveForm("delete"); setMessage(""); setBookingDetails(null); }}>Delete Booking</button>
      </div>

      {activeForm && (
        <div className="booking-form">
          {(activeForm === "add" || activeForm === "update") && (
            <>
              <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleChange} />
              <input type="number" name="workshopId" placeholder="Workshop ID" value={formData.workshopId} onChange={handleChange} />
              <input type="number" name="numberOfBooking" placeholder="Number of Booking" value={formData.numberOfBooking} onChange={handleChange} />
            </>
          )}
          {(activeForm === "update" || activeForm === "get" || activeForm === "delete") && (
            <input type="text" name="bookingId" placeholder="Enter Booking ID" value={formData.bookingId} onChange={handleChange} />
          )}
          <button onClick={handleSubmit}>Submit</button>
        </div>
      )}

      {message && <p className="message">{message}</p>}

      {bookingDetails && (
        <div className="booking-detail">
          <h4>Booking Details</h4>
          <p><strong>Booking ID:</strong> {bookingDetails.bookingId}</p>
          <p><strong>Name:</strong> {bookingDetails.name}</p>
          <p><strong>Workshop ID:</strong> {bookingDetails.workshopId}</p>
          <p><strong>Number of Booking:</strong> {bookingDetails.numberOfBooking}</p>
          {bookingDetails.amount && <p><strong>Amount:</strong> ₹{bookingDetails.amount}</p>}
          {bookingDetails.status && <p><strong>Status:</strong> {bookingDetails.status}</p>}
        </div>
      )}
    </div>
  );
}

export default BookingOperation;
