import { useState, useEffect } from "react";
import Login from "./authentication/login";
import Register from "./authentication/registration";
import WorkshopOperation from "./component/WorkshopOperation";
import FareOperation from "./component/FareOperation";
import BookingOperation from "./component/BookingOperation";
import Chatbot from "./component/Chatbot";
import './App.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState(null);
  const [showLogin, setShowLogin] = useState(true);
  const [activeComponent, setActiveComponent] = useState("workshop");

  useEffect(() => {
    const token = localStorage.getItem("token");
    const user = localStorage.getItem("username");
    if (token) {
      setIsAuthenticated(true);
      setUsername(user || null);
    }
  }, []);

  const handleLogin = (loggedInUsername) => {
    setIsAuthenticated(true);
    setUsername(loggedInUsername);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    setIsAuthenticated(false);
    setUsername(null);
  };

  const renderComponent = () => {
    switch (activeComponent) {
      case "workshop":
        return <WorkshopOperation />;
      case "fare":
        return <FareOperation />;
      case "booking":
        return <BookingOperation />;
      case "chatbot":
        return <Chatbot />;
      default:
        return null;
    }
  };

  return (
    <div>
      {!isAuthenticated && (
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh" }}>
          <div className="auth-card">
            {showLogin ? (
              <>
                <Login onLogin={handleLogin} />
                <p style={{ marginTop: "15px", color: "#fff" }}>
                  Don't have an account?{" "}
                  <button className="toggle-btn" onClick={() => setShowLogin(false)}>Register</button>
                </p>
              </>
            ) : (
              <>
                <Register />
                <p style={{ marginTop: "15px", color: "#fff" }}>
                  Already have an account?{" "}
                  <button className="toggle-btn" onClick={() => setShowLogin(true)}>Login</button>
                </p>
              </>
            )}
          </div>
        </div>
      )}

      {isAuthenticated && (
        <div className="dashboard-container">
          <div className="top-bar">
            <div className="welcome-msg">Welcome, {username}</div>
            <div className="system-title">WorkShop Registration System</div>
            <button className="logout-btn" onClick={handleLogout}>Logout</button>
          </div>

          <div className="nav-buttons">
            <button className="nav-btn" onClick={() => setActiveComponent("workshop")}>WorkshopOperation</button>
            <button className="nav-btn" onClick={() => setActiveComponent("fare")}>FareOperation</button>
            <button className="nav-btn" onClick={() => setActiveComponent("booking")}>BookingOperation</button>
            <button className="nav-btn" onClick={() => setActiveComponent("chatbot")}>Chatbot</button>
          </div>

          <div className="operation-container">
            {renderComponent()}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
