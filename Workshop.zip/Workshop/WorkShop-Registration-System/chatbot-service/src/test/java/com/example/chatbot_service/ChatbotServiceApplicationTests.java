package com.example.chatbot_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatbotServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
