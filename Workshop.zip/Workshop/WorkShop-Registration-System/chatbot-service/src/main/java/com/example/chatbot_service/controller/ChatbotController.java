package com.example.chatbot_service.controller;

import com.example.chatbot_service.service.ChatbotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/chatbot")
@CrossOrigin(origins = "http://localhost:3000")
public class ChatbotController {

    @Autowired
    private ChatbotService chatbotService;

    @GetMapping("/ask")
    public String ask(@RequestParam String message) {
        return chatbotService.getChatResponse(message);
    }
}

