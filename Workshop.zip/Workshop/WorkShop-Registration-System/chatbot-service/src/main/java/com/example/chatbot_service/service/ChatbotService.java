package com.example.chatbot_service.service;

import com.example.chatbot_service.dto.Booking;
import com.example.chatbot_service.dto.Fare;
import com.example.chatbot_service.dto.Workshop;
import com.example.chatbot_service.feingClient.BookingClient;
import com.example.chatbot_service.feingClient.FareClient;
import com.example.chatbot_service.feingClient.WorkshopClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ChatbotService {

    @Value("${azure.openai.key}")
    private String apiKey;

    private final AzureOpenAIClient azureClient;
    private final String deploymentName;

    private final WorkshopClient workshopClient;
    private final FareClient fareClient;
    private final BookingClient bookingClient;

    public ChatbotService(AzureOpenAIClient azureClient,
                          @Value("${azure.openai.deployment-name}") String deploymentName,
                          WorkshopClient workshopClient,
                          FareClient fareClient,
                          BookingClient bookingClient) {
        this.azureClient = azureClient;
        this.deploymentName = deploymentName;
        this.workshopClient = workshopClient;
        this.fareClient = fareClient;
        this.bookingClient = bookingClient;
    }

    public String getChatResponse(String userMessage) {
        // Agar user koi workshop id poochta hai
        if (userMessage.toLowerCase().contains("workshop")) {
            try {
                // Simple extraction for example, assume user types "workshop 1"
                Long workshopId = Long.parseLong(userMessage.replaceAll("[^0-9]", ""));
                Workshop workshop = workshopClient.getWorkshopById(workshopId);
                if (workshop != null) {
                    userMessage += "\nWorkshop Info: Title - " + workshop.getTitle()
                            + ", Date - " + workshop.getDate()
                            + ", Venue - " + workshop.getVenue()
                            + ", Available Seats - " + workshop.getAvailableSeats();
                }
            } catch (Exception e) {
                // Ignore if parsing fails
            }
        }

        if (userMessage.toLowerCase().contains("fare")) {
            try {
                Long fareId = Long.parseLong(userMessage.replaceAll("[^0-9]", ""));
                Fare fare = fareClient.getFareById(fareId);
                if (fare != null) {
                    userMessage += "\nFare Info: Price - " + fare.getPrice();
                }
            } catch (Exception e) {}
        }

        if (userMessage.toLowerCase().contains("booking")) {
            try {
                Long bookingId = Long.parseLong(userMessage.replaceAll("[^0-9]", ""));
                Optional<Booking> bookingOpt = bookingClient.getBookingById(bookingId);
                if (bookingOpt.isPresent()) {
                    Booking booking = bookingOpt.get();
                    userMessage += "\nBooking Info: Name - " + booking.getName()
                            + ", WorkshopId - " + booking.getWorkshopId()
                            + ", Number of Booking - " + booking.getNumberOfBooking()
                            + ", Status - " + booking.getStatus();
                }
            } catch (Exception e) {}
        }

        // Azure OpenAI ko updated userMessage bhejna
        Map<String, Object> requestBody = Map.of(
                "messages", List.of(Map.of("role", "user", "content", userMessage)),
                "max_tokens", 200,
                "temperature", 0.7
        );

        Map<String, Object> response = azureClient.sendRequest(deploymentName, requestBody, apiKey);

        if (response != null && response.containsKey("choices")) {
            Map firstChoice = ((List<Map>) response.get("choices")).get(0);
            Map message = (Map) firstChoice.get("message");
            return message.get("content").toString();
        }

        return "Sorry, I couldn't process your request.";
    }
}
