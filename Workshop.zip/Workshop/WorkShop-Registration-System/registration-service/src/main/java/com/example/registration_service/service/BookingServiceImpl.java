package com.example.registration_service.service;

import com.example.registration_service.dto.*;
import com.example.registration_service.entity.Booking;
import com.example.registration_service.exception.BookingAllreadyAvailableException;
import com.example.registration_service.exception.BookingNotFoundException;
import com.example.registration_service.feing.FareClient;
import com.example.registration_service.feing.WorkshopClient;
import com.example.registration_service.payclient.PayClient;
import com.example.registration_service.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private PayClient payClient;

    @Autowired
    private WorkshopClient workshopClient;

    @Autowired
    private FareClient fareClient;

    @Override
    public Booking createBooking(BookingRequest bookingRequest) throws BookingAllreadyAvailableException {
        Long workshopId = bookingRequest.getWorkshopId();

        // Duplicate booking check -> name + workshopId
        Booking existingBooking = bookingRepository.findByNameAndWorkshopId(
                bookingRequest.getName(), workshopId);
        if (existingBooking != null) {
            throw new BookingAllreadyAvailableException("Booking already done for this workshop.");
        }

        // Workshop details Feign se
        Workshop workshop = workshopClient.getWorkshopById(workshopId);
        if (workshop == null) {
            throw new RuntimeException("Workshop not found for Id: " + workshopId);
        }

        // Fare details Feign se
        Fare fare = fareClient.getFareById(workshopId);
        if (fare == null) {
            throw new RuntimeException("Fare not found for Workshop Id: " + workshopId);
        }

        // Payment Request
        PaymentRequest paymentRequest = new PaymentRequest();
        long amount = (long) fare.getPrice();
        paymentRequest.setAmount(amount);
        paymentRequest.setQuantity(bookingRequest.getNumberOfBooking());
        paymentRequest.setCurrency("INR");
        StripeResponse paymentResponse = payClient.makePayment(paymentRequest);

        if (!"SUCCESS".equalsIgnoreCase(paymentResponse.getStatus())) {
            throw new RuntimeException("Payment Failed: " + paymentResponse.getMessage());
        }

        // New booking create
        Booking booking = new Booking();
        booking.setName(bookingRequest.getName());
        booking.setWorkshopId(workshopId);
        booking.setNumberOfBooking(bookingRequest.getNumberOfBooking());

        booking.setTitle(workshop.getTitle());
        booking.setDescription(workshop.getDescription());
        booking.setDate(workshop.getDate());
        booking.setStartTime(workshop.getStartTime());
        booking.setEndTime(workshop.getEndTime());
        booking.setVenue(workshop.getVenue());
        booking.setAmount(amount);
        booking.setCreatedBy(workshop.getCreatedBy());
        booking.setSessionId(paymentResponse.getSessionId());
        booking.setSessionUrl(paymentResponse.getSessionUrl());
        booking.setStatus("CONFIRMED");

        return bookingRepository.save(booking);
    }

    @Override
    public Optional<Booking> getBookingById(Long id) throws BookingNotFoundException {
        Optional<Booking> booking = bookingRepository.findById(id);
        if (booking.isEmpty()) {
            throw new BookingNotFoundException("Booking Not Found");
        }
        return booking;
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Booking updateBooking(Long id, BookingRequest bookingRequest) throws BookingNotFoundException {
        Optional<Booking> getById = bookingRepository.findById(id);
        if (getById.isPresent()) {
            Booking booking = getById.get();
            booking.setName(bookingRequest.getName());
            booking.setWorkshopId(bookingRequest.getWorkshopId());
            booking.setNumberOfBooking(bookingRequest.getNumberOfBooking());
            return bookingRepository.save(booking);
        } else {
            throw new BookingNotFoundException("Booking Not Found");
        }
    }

    @Override
    public void cancelBooking(Long id) throws BookingNotFoundException {
        if (bookingRepository.existsById(id)) {
            bookingRepository.deleteById(id);
        } else {
            throw new BookingNotFoundException("Booking Not Found");
        }
    }
}
