package com.example.registration_service.exception;

public class BookingNotFoundException extends Exception{
    public BookingNotFoundException(String message){
        super(message);
    }
}
