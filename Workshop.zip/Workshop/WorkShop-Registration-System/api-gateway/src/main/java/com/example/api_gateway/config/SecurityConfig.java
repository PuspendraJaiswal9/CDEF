package com.example.api_gateway.config;

import com.example.api_gateway.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.server.SecurityWebFilterChain;


@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {


    private final JwtAuthenticationFilter jwtAuthenticationFilter;


    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }


    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        return http
                .csrf(csrf -> csrf.disable())
                .authorizeExchange(exchanges -> exchanges
// public endpoints for login/register and docs
                                .pathMatchers("/user/login", "/user/register", "/eureka/**", "/swagger-ui.html", "/swagger-ui/**",
                                        "/v3/api-docs/**", "/swagger-resources/**", "/webjars/**")
                                .permitAll()


// Workshop Service: only ADMIN can add/update/delete, USER/ADMIN can GET
                                .pathMatchers(HttpMethod.POST, "/api/workshops").hasRole("ADMIN")
                                .pathMatchers(HttpMethod.PUT, "/api/workshops/**").hasRole("ADMIN")
                                .pathMatchers(HttpMethod.DELETE, "/api/workshops/**").hasRole("ADMIN")
                                .pathMatchers(HttpMethod.GET, "/api/workshops/**").hasAnyRole("USER", "ADMIN")


// Fare Service: only ADMIN can add/update/delete, USER/ADMIN can GET
                                .pathMatchers(HttpMethod.POST, "/fares").hasRole("ADMIN")
                                .pathMatchers(HttpMethod.PUT, "/fares/**").hasRole("ADMIN")
                                .pathMatchers(HttpMethod.DELETE, "/fares/**").hasRole("ADMIN")
                                .pathMatchers(HttpMethod.GET, "/fares/**").hasAnyRole("USER", "ADMIN")


// Booking Service: both USER and ADMIN can perform all operations
                                .pathMatchers("/api/bookings/**").hasAnyRole("USER", "ADMIN")


// any other request must be authenticated
                                .anyExchange().authenticated()
                )
                .addFilterAt(jwtAuthenticationFilter, SecurityWebFiltersOrder.AUTHENTICATION)
                .build();
    }


    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
