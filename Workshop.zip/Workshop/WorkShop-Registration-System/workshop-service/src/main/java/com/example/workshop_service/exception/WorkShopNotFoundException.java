package com.example.workshop_service.exception;

public class WorkShopNotFoundException extends Exception{
    public WorkShopNotFoundException(String message){
        super(message);
    }
}
