package com.example.workshop_service.exception;

public class WorkShopAllreadyHaveAddedException extends Exception{
    public WorkShopAllreadyHaveAddedException(String message){
        super(message);
    }
}
